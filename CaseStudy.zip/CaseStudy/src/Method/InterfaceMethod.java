package Method;

public interface InterfaceMethod {
}
